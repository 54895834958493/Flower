from django.apps import AppConfig


class FlowerConfig(AppConfig):
    name = 'flower'
    verbose_name = 'Популярные букеты'

class OrdersConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'orders'
