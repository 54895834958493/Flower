from django.contrib import admin
from .models import Client, Shop, Flower, Order, OrderItem

admin.site.register(Client)
admin.site.register(Shop)
admin.site.register(Flower)
admin.site.register(Order)
admin.site.register(OrderItem)
